Map Tour version 2.2

This template is released under the Apache License V2.0 by Esri http://www.esri.com/.
Checkout the project repository on GitHub to access source code, latest revision, developer documentation, FAQ and tips.

https://github.com/Esri/map-tour-storytelling-template-js
